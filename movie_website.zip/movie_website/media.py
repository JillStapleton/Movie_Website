import webbrowser
# Imports webbrowser for the webbrowser.open function, which opens websites

class Movie():
	''' This class stores information about movies (title, poster, and trailer URL) '''
	def __init__(self,movie_title,poster_image,trailer_youtube):
		#this function initializes an instance of the class Movie
		self.title = movie_title
		self.poster_image_url = poster_image
		self.trailer_youtube_url = trailer_youtube
	
	def show_trailer(self):
		# This function opens the movie trailer
		webbrowser.open(self.trailer_youtube_url)
