import media #imports the media.py file where the class Movie is defined
import webbrowser #imports webbrowser for the webbrowser.open function, which opens websites
import fresh_tomatoes # imports the fresh_tomatoes file in order to call the open_movies_page() function, which builds the website structure

# Each instance of the class movie includes the title, poster url, and trailer url
fellowship=media.Movie(
	"Lord of the Rings: Fellowship of the King",
	"https://upload.wikimedia.org/wikipedia/en/0/0c/The_Fellowship_Of_The_Ring.jpg",
	"https://www.youtube.com/watch?v=qyquczkXgPc"
	)

towers=media.Movie(
	"Lord of the Rings: The Two Towers",
	"https://upload.wikimedia.org/wikipedia/en/a/ad/Lord_of_the_Rings_-_The_Two_Towers.jpg",
	"https://www.youtube.com/watch?v=2dlRvAjU_RI"	
	)

return_of=media.Movie(
	"Lord of the Rings: The Return of the King",
	"https://upload.wikimedia.org/wikipedia/en/9/9d/Lord_of_the_Rings_-_The_Return_of_the_King.jpg",
	"https://www.youtube.com/watch?v=Wmm5SNcjLvo"
	)

ado=media.Movie(
	"Much Ado About Nothing",
	"https://upload.wikimedia.org/wikipedia/en/f/f4/Much_ado_about_nothing_movie_poster.jpg",
	"https://www.youtube.com/watch?v=zk3GEGUVPNU"
	)

sense=media.Movie(
	"Sense and Sensability",
	"https://upload.wikimedia.org/wikipedia/en/6/69/Sense_and_sensibility.jpg",
	"https://www.youtube.com/watch?v=eJMnm28vAqQ"
	)

pride=media.Movie(
	"Pride and Predjudice",
	"http://static.rogerebert.com/uploads/movie/movie_poster/pride-and-prejudice-2005/large_lAb9l4kgc6QWnHamBzTnskt71A7.jpg",
	"https://www.youtube.com/watch?v=ARWfCBr0ZDM"
	)


# List of my favorite movies and the function that opens the movies page
movies = [fellowship,towers,return_of,ado,sense,pride]
fresh_tomatoes.open_movies_page(movies)
